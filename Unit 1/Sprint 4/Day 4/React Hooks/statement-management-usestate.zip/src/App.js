import "./styles.css";
import { useState } from "react";

export default function App() {
  let [count, setCount] = useState(0);

  // let increment = () => {
  //   setCount(count + 1);
  // };

  // let decrement = () => {
  //   setCount(count - 1);
  // };

  return (
    <div className="App">
      <h1>Statement Manangement</h1>
      <hr />
      <p>
        Count: <span id="count">{count}</span>
      </p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button disabled={count == 0} onClick={() => setCount(count - 1)}>
        Decrement
      </button>
    </div>
  );
}

//To Manage State we have following hooks:
//1. useState
//2. useReducer

//3. Redux
