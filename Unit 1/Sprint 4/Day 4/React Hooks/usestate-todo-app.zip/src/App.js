import "./styles.css";
import { useState } from "react";

function TodoCard(props) {
  return (
    <div>
      <h2>{props.task}</h2>
      <h4>{props.priority}</h4>
      <p>{props.user}</p>
    </div>
  );
}

export default function App() {
  const [todo, setTodo] = useState({
    id: "",
    task: "",
    priority: "",
    user: "",
  });

  const [todos, setTodos] = useState([]);

  console.log(todos);

  let changeHandler = (e) => {
    const { name, value } = e.target;
    console.log(name);
    setTodo({
      ...todo,
      [name]: value,
    });
  };

  let submitHandler = (e) => {
    e.preventDefault();

    setTodos([...todos, todo]);
  };

  return (
    <div className="App">
      <div className="todo-form">
        <form
          style={{
            display: "flex",
            flexDirection: "column",
          }}
          onSubmit={submitHandler}
        >
          <input
            onChange={changeHandler}
            name="id"
            type="text"
            placeholder="Enter Id"
          />
          <br />

          <input
            name="task"
            type="text"
            onChange={changeHandler}
            placeholder="Enter Task"
          />
          <br />

          <div style={{ display: "flex", gap: "10px" }}>
            <label htmlFor="Priority">Enter Priority</label>
            <select onChange={changeHandler} name="priority">
              <option value="">options</option>
              <option value="high">High</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
            </select>
          </div>
          <br />
          <input
            name="user"
            type="text"
            onChange={changeHandler}
            placeholder="Enter Username"
          />
          <br />

          <input type="submit" value="Add Todo" />
        </form>
      </div>
      <hr />

      <div className="todos">
        {todos.map(({ task, priority, user }, index) => (
          <TodoCard key={index} task={task} priority={priority} user={user} />
        ))}
      </div>
    </div>
  );
}
