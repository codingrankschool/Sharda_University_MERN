import "./styles.css";

import { useEffect, useState } from "react";

export default function App() {
  // let [count, setCount] = useState(0);
  // let [loading, setLoading] = useState(false);

  let [post, setPost] = useState([]);

  // //onMount - on first render - on state change
  // useEffect(() => {
  //   console.log(count);
  // });

  //onMount - on first render
  // useEffect(() => {
  //   console.log(count);
  // }, []);

  //onUpdate - firstTime or on state Update
  // useEffect(() => {
  //   console.log(count);
  // }, [loading]);

  //onUnMount - when remove from ui
  // useEffect(() => {
  //   console.log("OnCountChange or OnMount", count);
  //   return () => {
  //     console.log("UnMount", count);
  //   };
  // }, [count]);

  let getPost = async () => {
    let response = await fetch(`https://jsonplaceholder.typicode.com/posts`);
    let data = await response.json();

    setPost([...data]);
  };

  console.log(post);

  useEffect(() => {
    getPost();
  }, []);

  return (
    <div className="App">
      {/* <p>Count: {count}</p> */}
      {/* <button onClick={() => setCount(count + 1)}>Increment</button> */}
      <p>Getting Data</p>
    </div>
  );
}

/*
useEffect hook - handles the sideeffect of particular component

- Note: useEffect maintains the lifecyle of the component

1. First Render - onMount
2. Second Render - onUpdate
3. Third Render - onUnMount

*/
