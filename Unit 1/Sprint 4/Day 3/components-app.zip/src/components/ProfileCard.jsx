export default function ProfileCard(props) {
  return (
    <div style={{ border: "1px solid red", margin: "10px", padding: "10px" }}>
      <h2>{props.title}</h2>
      <p>{props.email}</p>
      <p>{props.number}</p>
    </div>
  );
}
