import "./styles.css";
import ProfileCard from "./components/ProfileCard";
import Button from "./components/Button";

export default function App() {
  // console.log("Hello");

  let students = [
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
    {
      name: "Rakesh",
      email: "rakesh@gmail.com",
      number: "12324232232",
    },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {students.map((student, index) => (
        <ProfileCard
          title={student.name}
          email={student.email}
          number={student.number}
        />
      ))}
    </div>
  );
}
